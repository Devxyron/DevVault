import "./globals.css";

export const metadata = {
  title: "DevVault — Developer Toolkit",
  description:
    "Everything developers need — formatters, converters, generators, and inspectors in one fast, premium workspace.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
