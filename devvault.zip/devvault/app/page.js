"use client";

import dynamic from "next/dynamic";

const DevVault = dynamic(() => import("../components/DevVault"), {
  ssr: false,
  loading: () => (
    <div
      style={{
        minHeight: "100vh",
        background: "#050505",
        color: "#9CA3AF",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "ui-sans-serif, system-ui, sans-serif",
        fontSize: 14,
      }}
    >
      Loading DevVault...
    </div>
  ),
});

export default function Page() {
  return <DevVault />;
}
